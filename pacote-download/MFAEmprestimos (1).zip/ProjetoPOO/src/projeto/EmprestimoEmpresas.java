package projeto;

public class EmprestimoEmpresas extends Emprestimo {


	public EmprestimoEmpresas(double valor, int parcelas) {
		super(valor, parcelas);
		
	}

	
	public double calcularJuros() {
		
		return this.valor*1.25;
	}

}


