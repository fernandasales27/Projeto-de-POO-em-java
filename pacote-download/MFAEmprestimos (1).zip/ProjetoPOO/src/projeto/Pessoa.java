package projeto;

public abstract class Pessoa {
	
	 private Endereco endereco;
	 private String nome;
	 private String dataDeNascimento;
	 private String telefone;
	 private String email;

	 	 
		public Pessoa() {
		super();
	}

		public Pessoa(String nome,  String dataDeNascimento, String telefone, String email, Endereco endereco) {
			super();
			
			this.nome = nome;
			this.dataDeNascimento = dataDeNascimento;
			this.telefone = telefone;
			this.email = email;
			this.endereco = endereco;
		}


	

		public String getNome() {
			return nome;
		}


		public void setNome(String nome) {
			this.nome = nome;
		}


	

		public String getDataDeNascimento() {
			return dataDeNascimento;
		}


		public void setDataDeNascimento(String dataDeNascimento) {
			this.dataDeNascimento = dataDeNascimento;
		}


		public String getTelefone() {
			return telefone;
		}


		public void setTelefone(String telefone) {
			this.telefone = telefone;
		}


		public String getEmail() {
			return email;
		}


		public void setEmail(String email) {
			this.email = email;
		}
		

		  public Endereco getEndereco() {
			return endereco;
		}


		public void setEndereco(Endereco endereco) {
			this.endereco = endereco;
		}

}
		

	  
	
	




