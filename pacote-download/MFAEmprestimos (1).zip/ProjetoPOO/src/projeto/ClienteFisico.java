package projeto;

public class ClienteFisico extends Cliente {
	private String CPF;
	private double rendaMensal;
	
	

	public ClienteFisico() {
		super();
	}


	public ClienteFisico(String nome, String dataDeNascimento, String telefone, String email, Endereco endereco,
			Contrato contrato, String CPF, double rendaMensal) {
		super(nome, dataDeNascimento, telefone, email, endereco, contrato);
		this.CPF = CPF;
		this.rendaMensal = rendaMensal;
	}


	public String getCPF() {
		return CPF;
	}


	public void setCPF(String cPF) {
		CPF = cPF;
	}

	public double getRendaMensal() {
		return rendaMensal;
	}

	public void setRendaMensal(double rendaMensal) {
		this.rendaMensal = rendaMensal;
	}
	
	

	

}
