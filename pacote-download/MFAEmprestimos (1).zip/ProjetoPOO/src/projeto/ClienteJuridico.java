package projeto;

public class ClienteJuridico extends Cliente {
	private String CNPJ;
	private double faturamentoAnual;
	

	public ClienteJuridico() {
		super();
	}

	public ClienteJuridico(String nome, String dataDeNascimento, String telefone, String email, Endereco endereco,
			Contrato contrato, String cNPJ, double faturamentoAnual) {
		super(nome, dataDeNascimento, telefone, email, endereco, contrato);
		CNPJ = cNPJ;
		this.faturamentoAnual = faturamentoAnual;
	}
	
	public String getCNPJ() {
		return CNPJ;
	}
	public void setCNPJ(String cNPJ) {
		CNPJ = cNPJ;
	}
	public double getFaturamentoAnual() {
		return faturamentoAnual;
	}
	public void setFaturamentoAnual(double faturamentoAnual) {
		this.faturamentoAnual = faturamentoAnual;
	}

	
	

}
