package projeto;

import java.util.List;

import javax.swing.JOptionPane;

import java.util.ArrayList;

public class Gerente extends Pessoa {
	
	private int ID;
	private List<Consultor> consultores= new ArrayList<Consultor>();
	
	
	public Gerente(String nome, String dataDeNascimento, String telefone, String email,
			Endereco endereco, int ID) {
		super( nome, dataDeNascimento, telefone, email, endereco);
		this.ID = ID;
	}
	
	public void acompanharConsultor() {
		String mensagem = "";
		  
		  String idConsultorString = JOptionPane.showInputDialog(null, "Digite o ID do consultor: ", "Acompanhar Consultor", JOptionPane.PLAIN_MESSAGE);
		
		  int idConsultor = 0;
		  if (idConsultorString != null && !idConsultorString.isEmpty() && idConsultorString.matches("\\d+")) {
		    
		    try {
		      idConsultor = Integer.parseInt(idConsultorString);
		    } catch (NumberFormatException e) {
		     
		      System.out.println("O ID do consultor deve ser um número inteiro.");
		      return;
		    }
		  } else {
		
		    System.out.println("O ID do consultor não pode ser nulo, vazio ou conter caracteres não numéricos.");
		    return;
		  }
		 
		  
		  for (Consultor c : consultores) {
		    if (c.getID() == idConsultor) { 
		    	mensagem +="Consultor: " + c.getNome()+ "\n" ; 
		    	mensagem +="Email: " + c.getEmail()+ "\n" ; 
		    	mensagem += "ID: " + c.getID()+ "\n" ; 
		    	mensagem +="----------------------------"+ "\n" ;
		      for (Cliente ci : c.getClientes()) {
		    	  mensagem += "Cliente: " + ci.getNome()+ "\n" ;
		    	  mensagem += "Email: " + ci.getEmail()+ "\n" ;
		    	  mensagem += "-------------------------------------"+ "\n";
		          mensagem += "\n";
			}			     
		    }
		  } 
		  
		  JOptionPane.showMessageDialog(null, mensagem);
		  
	}
	
	public void acompanharContrato() {
		String mensagem = "";
		String idConsultorString = JOptionPane.showInputDialog(null, "Digite o ID do consultor: ", "Acompanhar Consultor", JOptionPane.PLAIN_MESSAGE);
		int idConsultor = 0;
		idConsultor = Integer.parseInt(idConsultorString);
		
		for (Consultor c : consultores) {
			    if (c.getID() == idConsultor) { 
			    	mensagem += "Consultor: " + c.getNome() + "\n" ; 	   
			    	mensagem += "---------------------------------------------" + "\n";
			      for (Cliente ci : c.getClientes()) {
			    	  mensagem +="Nome: " + ci.getNome()+ "\n";
			    	  mensagem +="Email: " + ci.getEmail()+ "\n";
			    	  mensagem +="Número do contrato:  " + ci.getContrato().getNumero() + "\n";
			    	  mensagem +="Credor:  " + ci.getContrato().getCredor() + "\n";
			    	  mensagem +="Data de contratação:  " + ci.getContrato().getDataDeContratacao() + "\n";
			    	  mensagem +="Data de vencimento:  " + ci.getContrato().getDataDeVencimento() + "\n";
			    	  mensagem +="Valor:  " + ci.getContrato().getValor() + "\n";
			    	  mensagem +="Prazo:  " + ci.getContrato().getPrazo() + "\n";
			    	  mensagem +="-------------------------------------"+ "\n";
			          mensagem += "\n";
				}			     			     
			    }
			  }	
		  JOptionPane.showMessageDialog(null, mensagem);

	}
	public int getID() {
		return ID;
	}

	public void setID(int iD) {
		ID = iD;
	}

	public List<Consultor> getConsultores() {
		return consultores;
	}

	public void setConsultores(List<Consultor> consultores) {
		this.consultores = consultores;
	}

}
