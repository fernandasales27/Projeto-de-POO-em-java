package projeto;

import java.util.List;
import java.util.ArrayList;
import javax.swing.JOptionPane;


public class Consultor extends Pessoa {

	private List<Cliente> clientes= new ArrayList <Cliente>();
	private int ID;
	
	public Consultor(String nome, String dataDeNascimento, String telefone, String email, Endereco endereco, int iD) {
		super(nome, dataDeNascimento, telefone, email, endereco);
		this.ID = iD;
	}
	public void consultarCliente() {
		String mensagem = "";
		
		for (Cliente c : clientes) {
			mensagem +="--------------------------------------" +"\n" ;
			mensagem +="Nome: " + c.getNome()+ "\n" ;
			mensagem +="Telefone: " + c.getTelefone()+ "\n" ;
			mensagem +="Data de Nascimento: " + c.getDataDeNascimento()+ "\n" ;
			mensagem +="Contrato: " + c.getContrato().getNumero()+ "\n" ;
			mensagem +="Data de Contratação: " + c.getContrato().getDataDeContratacao()+ "\n" ;
			mensagem +="Valor: " + "R$"+c.getContrato().getValor()+ "\n" ;
			mensagem +="Endereço: " + c.getEndereco()+ "\n" ;
			mensagem +="--------------------------------------"+ "\n" ;
		}
		JOptionPane.showMessageDialog(null, mensagem);
	}
	
	public void simulacaoEmprestimo() {
		int tipo = Integer.parseInt(JOptionPane.showInputDialog(null, "Selecione o tipo de cliente: \n 1)Cliente Físico \n 2)Cliente Jurídico", "Simulação Empréstimo", JOptionPane.PLAIN_MESSAGE));
		if (tipo ==  1) {
			double rendaMensal = Double.parseDouble((JOptionPane.showInputDialog(null, "Insira a renda mensal", "Simulação Empréstimo", JOptionPane.PLAIN_MESSAGE)));
			double valor = Double.parseDouble((JOptionPane.showInputDialog(null, "Insira o valor desejado", "Simulação Empréstimo", JOptionPane.PLAIN_MESSAGE)));
			int prazo = Integer.parseInt((JOptionPane.showInputDialog(null, "Insira o prazo para pagamento do empréstimo:", "Simulação Empréstimo", JOptionPane.PLAIN_MESSAGE)));
			
			EmprestimoPessoal empPessoal = new EmprestimoPessoal(valor, prazo);
			
			if (valor+empPessoal.calcularJuros()/prazo >= rendaMensal/3) {
				JOptionPane.showMessageDialog(null, "Cliente está apto para o empréstimo", "Parabéns!", JOptionPane.PLAIN_MESSAGE);
			}else JOptionPane.showMessageDialog(null, "Cliente não está apto para o empréstimo", "Tente com outras condições!", JOptionPane.PLAIN_MESSAGE);
			
			
		}else if (tipo == 2) {
			double faturamentoMensal = Double.parseDouble((JOptionPane.showInputDialog(null, "Insira o faturamento Mensal", "Simulação Empréstimo", JOptionPane.PLAIN_MESSAGE)));
			double valor = Double.parseDouble((JOptionPane.showInputDialog(null, "Insira o valor desejado", "Simulação Empréstimo", JOptionPane.PLAIN_MESSAGE)));
			int prazo = Integer.parseInt((JOptionPane.showInputDialog(null, "Insira o prazo para pagamento do empréstimo:", "Simulação Empréstimo", JOptionPane.PLAIN_MESSAGE)));
			
			EmprestimoEmpresas empEmpresas = new EmprestimoEmpresas(valor, prazo);
			
			if (valor+empEmpresas.calcularJuros()/prazo >= faturamentoMensal/3) {
				JOptionPane.showMessageDialog(null, "Cliente está apto para o empréstimo", "Parabéns!", JOptionPane.PLAIN_MESSAGE);
			}else JOptionPane.showMessageDialog(null, "Cliente não está apto para o empréstimo", "Tente com outras condições!", JOptionPane.PLAIN_MESSAGE);
			
	}
	}
	public void cadastroCliente()  {
		int tipo = Integer.parseInt(JOptionPane.showInputDialog(null, "Selecione o tipo de cliente: \n 1)Cliente Físico \n 2)Cliente Jurídico", "Cadastro do Cliente", JOptionPane.PLAIN_MESSAGE));
			if (tipo ==  1) {
				Cliente cliente = new ClienteFisico();
				cliente.setNome(JOptionPane.showInputDialog(null, "Insira o nome:", "Cadastro do Cliente", JOptionPane.PLAIN_MESSAGE));
				((ClienteFisico) cliente).setCPF(JOptionPane.showInputDialog(null, "Insira o CPF:", "Cadastro do Cliente", JOptionPane.PLAIN_MESSAGE));
				cliente.setDataDeNascimento(JOptionPane.showInputDialog(null, "Insira o data de nascimento:", "Cadastro do Cliente", JOptionPane.PLAIN_MESSAGE));
				cliente.setEmail(JOptionPane.showInputDialog(null, "Insira o e-mail:", "Cadastro do Cliente", JOptionPane.PLAIN_MESSAGE));
				cliente.setTelefone(JOptionPane.showInputDialog(null, "Insira o telefone:", "Cadastro do Cliente", JOptionPane.PLAIN_MESSAGE));
				((ClienteFisico) cliente).setRendaMensal(Double.parseDouble((JOptionPane.showInputDialog(null, "Insira a renda mensal", "Cadastro do Cliente", JOptionPane.PLAIN_MESSAGE))));
				
				Contrato contrato = new Contrato();
				cliente.setContrato(contrato);
				cliente.getContrato().setPrazo(Integer.parseInt((JOptionPane.showInputDialog(null, "Insira o prazo para pagamento do empréstimo:", "Cadastro do Cliente", JOptionPane.PLAIN_MESSAGE))));
				cliente.getContrato().setValor(Double.parseDouble((JOptionPane.showInputDialog(null, "Insira o valor desejado", "Cadastro do Cliente", JOptionPane.PLAIN_MESSAGE))));
				cliente.getContrato().setDataDeContratacao(JOptionPane.showInputDialog(null, "Insira a data de contratação:", "Cadastro do Cliente", JOptionPane.PLAIN_MESSAGE));
				
				Endereco endereco = new Endereco();				
				cliente.setEndereco(endereco);
				cliente.getEndereco().setCep(JOptionPane.showInputDialog(null, "Insira o CEP:", "Cadastro do Cliente", JOptionPane.PLAIN_MESSAGE));
				cliente.getEndereco().setEstado(JOptionPane.showInputDialog(null, "Insira o Estado:", "Cadastro do Cliente", JOptionPane.PLAIN_MESSAGE));
				cliente.getEndereco().setCidade(JOptionPane.showInputDialog(null, "Insira a Cidade:", "Cadastro do Cliente", JOptionPane.PLAIN_MESSAGE));
				cliente.getEndereco().setBairro(JOptionPane.showInputDialog(null, "Insira o Bairro:", "Cadastro do Cliente", JOptionPane.PLAIN_MESSAGE));
				cliente.getEndereco().setRua(JOptionPane.showInputDialog(null, "Insira o Rua:", "Cadastro do Cliente", JOptionPane.PLAIN_MESSAGE));
				cliente.getEndereco().setNumero(Integer.parseInt(JOptionPane.showInputDialog(null, "Insira o Numero:", "Cadastro do Cliente", JOptionPane.PLAIN_MESSAGE)));
								
				clientes.add(cliente);
				
			} else if (tipo == 2) {
				
				Cliente cliente = new ClienteJuridico();
				cliente.setNome(JOptionPane.showInputDialog(null, "Insira o nome:", "Cadastro do Cliente", JOptionPane.PLAIN_MESSAGE));
				((ClienteJuridico)cliente).setCNPJ(JOptionPane.showInputDialog(null, "Insira o CNPJ:", "Cadastro do Cliente", JOptionPane.PLAIN_MESSAGE));
				cliente.setDataDeNascimento(JOptionPane.showInputDialog(null, "Insira o data de nascimento:", "Cadastro do Cliente", JOptionPane.PLAIN_MESSAGE));
				cliente.setEmail(JOptionPane.showInputDialog(null, "Insira o e-mail:", "Cadastro do Cliente", JOptionPane.PLAIN_MESSAGE));
				cliente.setTelefone(JOptionPane.showInputDialog(null, "Insira o telefone:", "Cadastro do Cliente", JOptionPane.PLAIN_MESSAGE));
				((ClienteJuridico)cliente).setFaturamentoAnual(Double.parseDouble((JOptionPane.showInputDialog(null, "Insira o faturamento anual:", "Cadastro do Cliente", JOptionPane.PLAIN_MESSAGE))));
				
				Contrato contrato = new Contrato();
				cliente.setContrato(contrato);
				cliente.getContrato().setPrazo(Integer.parseInt((JOptionPane.showInputDialog(null, "Insira o prazo para pagamento do empréstimo:", "Cadastro do Cliente", JOptionPane.PLAIN_MESSAGE))));
				cliente.getContrato().setValor(Double.parseDouble((JOptionPane.showInputDialog(null, "Insira o valor desejado", "Cadastro do Cliente", JOptionPane.PLAIN_MESSAGE))));
				cliente.getContrato().setDataDeContratacao(JOptionPane.showInputDialog(null, "Insira a data de contratação:", "Cadastro do Cliente", JOptionPane.PLAIN_MESSAGE));
				
				Endereco endereco = new Endereco();				
				cliente.setEndereco(endereco);
				cliente.getEndereco().setCep(JOptionPane.showInputDialog(null, "Insira o CEP:", "Cadastro do Cliente", JOptionPane.PLAIN_MESSAGE));
				cliente.getEndereco().setEstado(JOptionPane.showInputDialog(null, "Insira o Estado:", "Cadastro do Cliente", JOptionPane.PLAIN_MESSAGE));
				cliente.getEndereco().setCidade(JOptionPane.showInputDialog(null, "Insira a Cidade:", "Cadastro do Cliente", JOptionPane.PLAIN_MESSAGE));
				cliente.getEndereco().setBairro(JOptionPane.showInputDialog(null, "Insira o Bairro:", "Cadastro do Cliente", JOptionPane.PLAIN_MESSAGE));
				cliente.getEndereco().setRua(JOptionPane.showInputDialog(null, "Insira o Rua:", "Cadastro do Cliente", JOptionPane.PLAIN_MESSAGE));
				cliente.getEndereco().setNumero(Integer.parseInt(JOptionPane.showInputDialog(null, "Insira o Numero:", "Cadastro do Cliente", JOptionPane.PLAIN_MESSAGE)));
				
				clientes.add(cliente);
				
			} 
			    
			  }
	

	public void acompanharContrato(int argumento) {
		int i=0;
		String mensagem = "";
		for (Cliente cliente : clientes) {
			if (cliente.getContrato().getNumero() == argumento) {
				 mensagem +="--------------------------------------"+ "\n";
				 mensagem +="Contrato: " + cliente.getContrato().getNumero()+"\n" ;
				 mensagem +="Nome do Comprador: " + cliente.getContrato().getComprador().getNome()+ "\n";
				 mensagem +="Data de Contratação: " + cliente.getContrato().getDataDeContratacao()+ "\n";
				 mensagem +="Data de Vencimento: " + cliente.getContrato().getDataDeVencimento()+ "\n";
				 mensagem +="Prazo: " + cliente.getContrato().getPrazo() + " meses"+ "\n";
				 mensagem +="Valor: " + "R$"+cliente.getContrato().getValor()+ "\n";
				 mensagem +="--------------------------------------"+ "\n";
				i++;
			} 
		} if (i==0) JOptionPane.showMessageDialog(null, "Numéro de contrato inválido. Tente Novamente!", "Acompanhar Contrato", JOptionPane.ERROR_MESSAGE);
		JOptionPane.showMessageDialog(null, mensagem);
	}

	public List<Cliente> getClientes() {
		return clientes;
	}

	public void setClientes(List<Cliente> clientes) {
		this.clientes = clientes;
	}

	public int getID() {
		return ID;
	}

	public void setID(int iD) {
		ID = iD;
	}
	

}
