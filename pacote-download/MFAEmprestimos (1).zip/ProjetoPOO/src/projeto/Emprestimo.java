package projeto;



public abstract class Emprestimo {

	
	public abstract double calcularJuros (); 

	
	protected double valor;
	protected int parcelas;

	
	  public Emprestimo (double valor, int parcelas) {
	    this.valor = valor;
	    this.parcelas=parcelas;


	  }

	
	  public double getValor() {
		return valor;
	}



	public void setValor(double valor) {
		this.valor = valor;
	}



	}

