package projeto;

public class Contrato {


	private int numero;
	private String dataDeContratacao;
	private String dataDeVencimento;
	private String credor;
	private Pessoa comprador;
	private Emprestimo emprestimo; 
	private double valor;
	protected int prazo;
	


	public Contrato() {
		super();
	}

	public Contrato(int numero, String dataDeContratacao, String dataDeVencimento, String credor, Pessoa comprador,
			Emprestimo emprestimo, double valor, int prazo) {
		super();
		this.numero = numero;
		this.dataDeContratacao = dataDeContratacao;
		this.dataDeVencimento = dataDeVencimento;
		this.credor = credor;
		this.comprador = comprador;
		this.emprestimo = emprestimo;
		this.valor = valor;
		this.prazo = prazo;
	}

	public int getNumero() {
		return numero;
	}

	public void setNumero(int numero) {
		this.numero = numero;
	}

	

	public int getPrazo() {
		return prazo;
	}


	public void setPrazo(int prazo) {
		this.prazo = prazo;
	}


	public String getCredor() {
		return credor;
	}



	public void setCredor(String credor) {
		this.credor = credor;
	}



	public Pessoa getComprador() {
		return comprador;
	}



	public void setComprador (Pessoa comprador) {
		this.comprador = comprador;
	}



	public Emprestimo getEmprestimo() {
		return emprestimo;
	}



	public void setEmprestimo(Emprestimo emprestimo) {
		this.emprestimo = emprestimo;
	}



	public double getValor() {
		return valor;
	}


	public void setValor(double valor) {
		this.valor = valor;
	}


	public String getDataDeContratacao() {
		return dataDeContratacao;
	}

	public void setDataDeContratacao(String dataDeContratacao) {
		this.dataDeContratacao = dataDeContratacao;
	}

	public String getDataDeVencimento() {
		return dataDeVencimento;
	}

	public void setDataDeVencimento(String dataDeVencimento) {
		this.dataDeVencimento = dataDeVencimento;
	}



	public void statusContrato () {

	}


}



