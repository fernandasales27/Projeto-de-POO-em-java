package projeto;

import javax.swing.JOptionPane;

public class Main {

	public static void main(String[] args) {


		Endereco e1 = new Endereco("Rua 1", 22, "Centro", "Palmares", "PE", "55540000");
		Endereco e2= new Endereco("rua2",13,"Centro","Palmares","PE","55540000");
		Endereco e3= new Endereco("rua 3",25,"São Pedro","Palmares","PE","55540000");

		Emprestimo ep1= new EmprestimoPessoal(15000, 36);
		Emprestimo ep2= new EmprestimoEmpresas(100000, 48);
		

		Consultor c1 = new Consultor("Antônio Borges", "26/04/97","9 81 8654-5698" , "antonio.borges@mfa.com.br", e1, 102030);

		Cliente cl1 = new ClienteFisico("Lia Antunes", "13/09/87", "9 81 6584-9656", "lia.antunes@gmail.com.br", e2, null, "896.364.956-44", 3600);
		Cliente cl2= new ClienteJuridico("VARFYK","6/06/2018","3661009","varfyk@gmail.com",e3,null,"34.345.566/0001-44",300.000);
		
		Contrato ct1=new Contrato(10001, "12/06/2023", "12/06/2025", "MFA Emprestimos", cl1, ep1, 15000, 36);
		Contrato ct2= new Contrato(10002, "14/08/2023", "14/08/2027", "MFA Emprestimos", cl2, ep2, 100000, 48);
		cl1.setContrato(ct1);
		
		cl2.setContrato(ct2);
		
		c1.getClientes().add(cl1);
		c1.getClientes().add(cl2);
		
		
		Endereco e4= new Endereco("Rua 4", 04, "Centro", "Ribeirão", "PE", "55520000");
		Endereco e5= new Endereco("Rua 5", 05,"Centro", "Água Preta","PE","55550000");
		Endereco e6= new Endereco("Rua 6", 06, "Centro", "Gameleira", "PE", "55530000");
		Endereco e7= new Endereco("Rua 07", 07, "Centro", "Palmares", "PE", "55540000");
		Endereco e8= new Endereco("Rua 8", 18, "Cohab 2", "Palmares", "PE", "55540000");
		
		Emprestimo ep3= new EmprestimoPessoal(20000, 36);
		Emprestimo ep4= new EmprestimoEmpresas(250000, 48);
		Emprestimo ep5= new EmprestimoPessoal(10000, 24);
		
		Consultor c2= new Consultor("Amanda Lins", "01/09/1990", "81 9-99663322", "amanda.lins@mfa.com.br", e4, 102040);

		Cliente cl3= new ClienteFisico("Guilherme Lira", "05/05/1985", "81 9-98963231", "guilherme.lira2gmail.com.br", e5, null, "021.879.874-77", 4200);
		Cliente cl4= new ClienteJuridico("Shelby LTDA", "07/12/1979", "3661-5159", "shelbyLTDA@gmail.com.br", e6, null,"75.325.536/0001-54", 550.000);
		Cliente cl5= new ClienteFisico("Roberto Santos", "12/08/1988", "81 9 98875-3266", "roberto.santos@gmail.com.br", e7, null, "896.565.784-32", 1200);

		Contrato ct3= new Contrato(10003, "22/09/2023", "22/09/2026", "MFA Emprestimos", cl3, ep3, 20000, 36);
		Contrato ct4= new Contrato(10004, "17/06/2023", "17/06/2027","MFA Emprestimos" , cl4, ep4, 250000, 48);
		Contrato ct5= new Contrato(10005, "12/05/2023", "12/05/2025","MFA Emprestimos" , cl5, ep5, 10000, 24);
	
		cl3.setContrato(ct3);
		cl4.setContrato(ct4);
		cl5.setContrato(ct5);
	
		c2.getClientes().add(cl3);
		c2.getClientes().add(cl4);
		c2.getClientes().add(cl5);

		
		Gerente g = new Gerente("Liz Monteiro", "04/06/1991", "81 9 9785-4612", "liz.monteiro@mfa.com.br", e8, 102020);
		

		g.getConsultores().add(c1);
		g.getConsultores().add(c2);

		
			
		JOptionPane.showMessageDialog(null, "Bem-vinde ao MFA Empréstimos!", "Boas Vindas", JOptionPane.PLAIN_MESSAGE);

	while (true) {	
				
		int perfil = Integer.parseInt(JOptionPane.showInputDialog(null, "Selecione um dos perfis abaixo: \n 1) Cliente \n 2) Consultor \n 3) Gerente \n 4) Sair", "Escolha seu perfil", JOptionPane.PLAIN_MESSAGE));
		int escolha = 0;
		if (perfil == 1) {
		    String ID = JOptionPane.showInputDialog(null, "Informe seu CPF/CNPJ", "Bem vindo, Cliente!", JOptionPane.PLAIN_MESSAGE);
		    for (Consultor consultor : g.getConsultores()) {
		        for (Cliente cliente : consultor.getClientes()) {
		            if (cliente instanceof ClienteFisico) {
		                if (((ClienteFisico) cliente).getCPF().equals(ID)) {
		                    escolha = Integer.parseInt(JOptionPane.showInputDialog(null, "Selecione a opção desejada \n 1) Acompanhar Contrato \n 2) Pagar parcela", "Área do Cliente", JOptionPane.PLAIN_MESSAGE));

		                    if (escolha == 1) {
		                    	cliente.acompanharContrato();
		                    } else if (escolha == 2) {
		                        cliente.pagarParcelas();
		                    } else {
		                    	JOptionPane.showMessageDialog(null, "Opção inválida!", "", JOptionPane.ERROR_MESSAGE);
		                    }
		                }

		            } else if (cliente instanceof ClienteJuridico) {
		                if (((ClienteJuridico) cliente).getCNPJ().equals(ID)) {
		                    escolha = Integer.parseInt(JOptionPane.showInputDialog(null, "Selecione a opção desejada \n 1) Acompanhar Contrato \n 2) Pagar parcela", "Área do Cliente", JOptionPane.PLAIN_MESSAGE));

		                    if (escolha == 1) {
		                        cliente.acompanharContrato();
		                    } else if (escolha == 2) {
		                        cliente.pagarParcelas();
		                    } else {
		                    	JOptionPane.showMessageDialog(null, "Opção inválida!", "", JOptionPane.ERROR_MESSAGE);
		                    }
		                }

		            }

		        }

		    }

		} else if (perfil == 2) {
		    String ID = JOptionPane.showInputDialog(null, "Informe seu ID", "Bem vindo, Consultor!", JOptionPane.PLAIN_MESSAGE);
		    for (Consultor consultor : g.getConsultores()) {
		    	if (Integer.parseInt(ID) == consultor.getID()) {
		            escolha = Integer.parseInt(JOptionPane.showInputDialog(null, "Selecione a opção desejada \n 1) Consultar Cliente \n 2) Simular Empréstimo  \n 3) Solicitar Contrato \n 4) Acompanhar Contrato", "Área do Consultor", JOptionPane.PLAIN_MESSAGE));
		            if (escolha == 1) {
		                consultor.consultarCliente();
		            } else if (escolha == 2) {
		                consultor.simulacaoEmprestimo();
		            } else if (escolha == 3) {
		            	consultor.cadastroCliente();
		            } else if (escolha == 4) {
		            	int argumento = Integer.parseInt(JOptionPane.showInputDialog(null, "Informe o número do contrato:", "Acompanhar Contrato", JOptionPane.PLAIN_MESSAGE));
		                consultor.acompanharContrato(argumento);
		            } else JOptionPane.showMessageDialog(null, "Opção inválida!", "", JOptionPane.ERROR_MESSAGE);

		        }

		    }
		} else if (perfil == 3) {
		    int ID = Integer.parseInt(JOptionPane.showInputDialog(null, "Informe seu ID", "Bem vindo, Gerente!", JOptionPane.PLAIN_MESSAGE));
		    if (ID == g.getID()) {
		        escolha = Integer.parseInt(JOptionPane.showInputDialog(null, "Selecione a opção desejada \n 1) Acompanhar Consultor \n 2) Acompanhar Contrato", "Área do Gerente", JOptionPane.PLAIN_MESSAGE));
		        if (escolha == 1) {
		            g.acompanharConsultor();
		        } else if (escolha == 2) {
		            g.acompanharContrato();
		        } else {
		        	JOptionPane.showMessageDialog(null, "Opção inválida!", "", JOptionPane.ERROR_MESSAGE);
		        }
		    }
		} else if (perfil == 4) break;
				
		else JOptionPane.showMessageDialog(null, "Opção inválida!", "", JOptionPane.ERROR_MESSAGE);
		
	}
}
}

