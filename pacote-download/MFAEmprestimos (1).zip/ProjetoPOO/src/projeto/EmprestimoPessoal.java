package projeto;

public class EmprestimoPessoal extends Emprestimo {



	public EmprestimoPessoal(double valor, int parcelas) {
		super(valor, parcelas);
		
	}

	
	public double calcularJuros() {
		
		return this.valor*1.3;
	}

}


