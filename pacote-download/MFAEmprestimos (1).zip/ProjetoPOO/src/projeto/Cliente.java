package projeto;

import javax.swing.JOptionPane;

public class Cliente extends Pessoa {
	
	 private Contrato contrato;

	 
	public Cliente() {
		super();
	}

	public Cliente(String nome, String dataDeNascimento, String telefone, String email, Endereco endereco,
			Contrato contrato) {
		super(nome, dataDeNascimento, telefone, email, endereco);
		this.contrato = contrato;
	}

	public void acompanharContrato() {
		String message = "Número do contrato:" + contrato.getNumero() + "\n" + " Data de contratação: " +
			    contrato.getDataDeContratacao() + "\n" + "Data de vencimento:" + contrato.getDataDeVencimento() +
			    "\n" + "Credor:" + contrato.getCredor() +
			    "\n" + "Comprador" + contrato.getComprador().getNome() + "\n" + "Emprestimo: " + "\n" +
			    "Valor do empréstimo R$: " + contrato.getEmprestimo().getValor() +
			    "\n" + "Valor do emprestimo com juros aplicado R$: " + contrato.getEmprestimo().calcularJuros() +
			    "parcelas: " + contrato.getEmprestimo().parcelas;

			JOptionPane.showMessageDialog(null, message);

	}
	
	public void pagarParcelas() {

		if(contrato.getEmprestimo() instanceof EmprestimoPessoal) {

			double valorNovo=(contrato.getEmprestimo().calcularJuros() );
			double parcelas=(contrato.getEmprestimo().calcularJuros()/ contrato.getEmprestimo().parcelas);
			String resultado= String.format("%.2f", valorNovo);
			String resultado2= String.format("%.2f", parcelas);
			double ctAtualizado=(contrato.getEmprestimo().calcularJuros()-parcelas) ;
			String resultado3= String.format("%.2f", ctAtualizado);

			String message = "---------MFA Emprestimos-----------" + "\n" + contrato.getDataDeVencimento() + "\n" +
				    "cliente: " + this.getNome() + "\n" + "Número do contrato: " + contrato.getNumero() + "\n " + "Valor do emprestimo: R$" +
				    contrato.getValor() + "\n" + "Valor do contrato com juros: R$" + resultado + "\n" + "Valor das parcelas R$: " + resultado2 +
				    "\n" + "Parcelas faltantes: " + (contrato.getEmprestimo().parcelas - 1) + "\n ";
				message += "--------------------------------" + "\n" + "Valor atual do contrato R$: " + "\n" +
				    resultado3 + "\n" + "\n" + "Pagamento efetuado com sucesso!" + "\n" + "--------------------------------";

				JOptionPane.showMessageDialog(null, message);


		}else if(contrato.getEmprestimo() instanceof EmprestimoEmpresas){
			
			double valorNovo=(contrato.getEmprestimo().calcularJuros() );
			double parcelas=(contrato.getEmprestimo().calcularJuros()/ contrato.getEmprestimo().parcelas);
			String resultado= String.format("%.2f", valorNovo);
			String resultado2= String.format("%.2f", parcelas);
			double ctAtualizado=(contrato.getEmprestimo().calcularJuros()-parcelas) ;
			String resultado3= String.format("%.2f", ctAtualizado);

			String message = "---------MFA Emprestimos-----------" + "\n" + contrato.getDataDeVencimento() + "\n" +
				    "Cliente: " + this.getNome() + "\n" + "Número do contrato: " + contrato.getNumero() + "\n " + "Valor do emprestimo: R$" +
				    contrato.getValor() + "\n" + "Valor do contrato com juros: R$" + resultado + "\n" + "Valor das parcelas R$: " + resultado2 +
				    "\n" + "Parcelas faltantes: " + (contrato.getEmprestimo().parcelas - 1) + "\n ";
				message += "--------------------------------" + "\n" + "Valor atual do contrato R$: " + "\n" +
				    resultado3 + "\n" + "\n" + "Pagamento efetuado com sucesso! " + "\n" + "--------------------------------";

				JOptionPane.showMessageDialog(null, message);

		}
	}


	public Contrato getContrato() {
		return contrato;
	}


	public void setContrato(Contrato contrato) {
		this.contrato = contrato;
	}
	

}
